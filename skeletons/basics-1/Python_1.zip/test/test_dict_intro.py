#!/usr/bin/python
# -*- coding: utf-8 -*-

from dicts import dict_intro

dict_intro()
